
int example_function(int in)
{
  return 3*in;
}

int main ()
{
  int x;
  x=example_function(13);
  return x;
}
