#include <stdio.h>

int main()
{
  printf("Hello World!\n");
  printf("Once again, hello! This was the %dnd time.\n",2);

  return 0;
}
