int global;

int main()
{
  global=10;

  return 0;
}
